How to?

1. Put winmm.dll, nvngx.dll, nvngx.ini into the game directory
2. Make sure you have run EnableSignatureOverride.reg at least once
3. Run the game in DirectX 12 mode